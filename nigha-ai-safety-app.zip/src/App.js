import React from 'react';
import './App.css';

function App() {
  return (
    <div className="App">
      <header className="App-header">
        <h1>Welcome to NIGHA AI Safety App</h1>
        <p>Empowering safety for women and girls using AI</p>
      </header>
    </div>
  );
}

export default App;